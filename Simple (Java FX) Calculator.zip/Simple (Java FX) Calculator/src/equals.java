
import javafx.application.Application;
import javafx.stage.Stage;


public class equals extends Application { //Point #8 - Class derivation
	 
	public Double equal(String txt){
		 String myString = txt;
		 double result = 0.0;
		 String[] parts = myString.split("(?<=[-+*/%])|(?=[-+*/%])"); //String - Point #9
        
		 try{
		  result = Double.parseDouble(parts[0]);
		 
		 for(int i = 1; i < parts.length; i +=2 )
		 {
			 String op = parts[i];
			 double value = Double.parseDouble(parts[i+1]);
			 
			 switch (op){
			 case "*":
				 result *= value;
				 break;
			 case "/":
				 result /= value;
				 break;
			 case "%":
				 result %= value;
				 break;
			 case "+":
				 result += value;
				 break;
			 case "-":
				 result -= value;
				 break;
			 }
		 }
		 
		 //txt1.setText(""+result);
		 }catch(Exception e)//Exception handling - point #4
		 {
			 //txt1.setText("Error: Invalid Input!");
		 }
		 	return result;	 
	 }

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
	}
	 }